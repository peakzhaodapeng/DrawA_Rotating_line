﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Drawing.Drawing2D;
using System.Drawing.Imaging;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public const int x=100;
         public const int  y=100;
         public const int l = 50;

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);
           // pic.DrawLine(pen_maliang, x, y, x + l * (int)(Math.Sin(Convert.ToSingle(textBox1.Text) / 180 * Math.PI)), y + l * (int)(Math.Cos((Convert.ToInt16(textBox1.Text) / 180) * Math.PI)));
            pic.DrawLine(pen_maliang, x, y, x + (int)(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI)), y + (int)(l * Math.Cos((hScrollBar1.Value) / 180f * Math.PI)));
            pic.DrawLine(pen_maliang, x, y, x + (int)(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI)), y);
            pic.DrawEllipse(pen_maliang,x-l,y-l,2*l,2*l);
            textBox3.Text = Convert.ToString(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI));
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text=Convert.ToString(Math.Sin(Convert.ToSingle(textBox2.Text)/180 * Math.PI));
        }
    }
}
